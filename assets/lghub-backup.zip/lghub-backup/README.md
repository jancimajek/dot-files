 - https://www.reddit.com/r/LogitechG/comments/ozxjnh/logitech_g_hub_backup_all_the_settings_how_to/


Logitech G HUB backup ALL THE SETTINGS - How to (step by step)
Discussion
Hi guys, since I had some problems trying to backup ALL THE SETTINGS (profiles, light settings and everything) I decided to post here the solution that worked for me, thanks to the redditor that found it (link below)

With this method I've been able to recover all my profiles as well as light settings and everything.

Step by step solution:

1- CREATE THE BACKUP

Go to the AppData>Roaming folder (type %appdata% in the Windows search bar, this will lend you to the AppData>Roaming folder, you can see it in the path showed at the top of the folder)

Copy the LGHUB folder you can find inside of the AppData>Roaming folder, and paste it where you prefer, as the first half of your backup ( I suggest you to put it in a new folder called "Roaming" or something similar, to remember that it's the one you took from the AppData> Roaming folder)

Go to the AppData>Local folder (you can reach it clicking on AppData in the path at the top of the window, as mentioned before. There you will find 3 folders (Local, LocalLow, Roaming), open the Local folder)

Copy the LGHUB folder you can find inside of the AppData>Local folder, and paste it where you prefer, as the second half of your backup (I suggest you to put it in a new folder called "Local" or something similar, to remember that it's the one you took from the AppData>Local folder)

END OF BACKUP PHASE
_____________________________________________________________________________________________

Now do whatever you need to do, uninstall and reinstall GHub, update it, or whatever.

If you reinstall GHub, you'll notice that all your profiles and settings are gone.
_____________________________________________________________________________________________

2- RELOAD THE BACKUP IN GHUB WITH ALL YOUR SETTINGS AND PROFILES

CLOSE LOGITECH G HUB SOFTWARE (I found it isn't necessary to close that before the next step, but NOW YOU NECESSARILY HAVE TO CLOSE IT)

Once GHub is not running, replace the two folders that we found before (AppData>Local>LGHUB, and AppData>Roaming>LGHUB) with the two LGHUB folders that we saved as backup.
Obviously you have to replace the AppData>Local>LGHUB with the LGHUB folder that we took from Local folder, and the same goes for the Roaming one.
Obviously again, you can find this two folders in the same way we found them before.

Open Logitech G HUB software, and now you should see all your profiles and settings are back.

I hope I've been useful to those who have encountered or will encounter the same problems as mine, and I thank all the redditors who have sought solutions in the past.

(link to the thread in which I found the solution, it's in the last comment: https://www.reddit.com/r/LogitechG/comments/efu1zq/where_are_the_ghub_profiles_located_on_disk/ )